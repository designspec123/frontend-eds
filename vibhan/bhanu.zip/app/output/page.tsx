"use client"
import { Button } from "@/components/ui/button"
import { ArrowBigLeft, CopyIcon } from "lucide-react"
import { useOutputStore } from "../useOutputStore";
import { Prism } from 'react-syntax-highlighter'

import { okaidia } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { useState } from "react";
import { cn } from "@/lib/utils";
import Link from "next/link";
import { useRouter } from "next/navigation";
const OutputPage = () => {
  const [tab, setTab] = useState("preview")
  const result = useOutputStore((state => state.output))
  const router=useRouter()
  return <div  className=" h-screen bg-cover  "     style={{
      background:"url('/images/eds-bg.jpg')"
    }}>
         <div className="container w-full p-5" >
  <div onClick={()=>{
    router.back()
  }}>
            {/* <Link href="/"> */}
            <ArrowBigLeft className=" text-white  " />
            {/* </Link> */}
        </div>
 <div className="bg-white/20 text-white pt-5 p-2 flex flex-col  text-4xljustify-center items-center">
    <div className="grid grid-cols-3 gap-10 mb-5 items-center">
  <div className="text-center col-start-2"> <h1 className="text-white text-4xl text-center">DesignConform</h1></div>

  <div className="flex justify-end space-x-2 col-start-3">
    <div
      className={cn(
        "text-white w-36 h-12 flex items-center justify-center text-center font-light border-2 border-white rounded cursor-pointer hover:bg-white hover:text-black transition-colors duration-200",
        tab === "preview" && "border-4"
      )}
      onClick={() => setTab('preview')}
    >
      Live Preview
    </div>

    <div
      className={cn(
        "text-white w-36 h-12 flex items-center justify-center text-center font-light border-2 border-white rounded cursor-pointer hover:bg-white hover:text-black transition-colors duration-200",
        tab === "code" && "border-4"
      )}
      onClick={() => setTab('code')}
    >
      Code
    </div>
  </div>
</div>

 </div>
    {tab === "code" && <Prism
      langauge="html"
      showLineNumbers={true}
      wrapLines={true}
      style={okaidia}

    >
      {result}
    </Prism>}
    {tab === "preview" && <iframe
      srcDoc={result || ""}
      sandbox="allow-scripts allow-same-origin"
      className="w-full h-[800px] bg-white mt-5"
      style={{
        border: "none"
      }}

    />}
  </div>
    </div>

}
export default OutputPage