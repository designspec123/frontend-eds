import { SplineIcon } from "lucide-react"

const LoaderPage=()=>{
    return <div style={{
        width:"100%",
        height:"100%",
        display:"flex",
        alignItems:"center",
        justifyContent:"center"
    }}>
    <SplineIcon className="animate-spin"/>    
    </div>
}
export default LoaderPage