import asyncio
from pathlib import Path
from playwright.async_api import async_playwright

# Path to your HTML file (use raw string for Windows paths)
HTML_FILE = "transformed_trybs_theme_company_full.htm"
#HTML_FILE = "bootstrap_sample.html"

async def run():
    file_url = Path(HTML_FILE).resolve().as_uri()

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        page = await browser.new_page()
        await page.goto(file_url)

        # --- Test Subscribe Section ---
        await page.locator('input[placeholder="Email Address"]').fill('test@example.com')
        await page.get_by_role("button", name="Subscribe").click()
        print("[✓] Clicked Subscribe after entering email")

        # --- Test Contact Form Section ---
        await page.fill('#name', 'John Doe')
        await page.fill('#email', 'john@example.com')
        await page.fill('#comments', 'This is a test comment.')

        await page.get_by_role("button", name="Send").click()
        print("[✓] Clicked Send after filling contact form")

        # Optional: check if fields retained values after clicking
        assert await page.input_value('#name') == 'John Doe'
        assert await page.input_value('#email') == 'john@example.com'
        assert await page.input_value('#comments') == 'This is a test comment.'

        print("[✓] Input fields validated successfully.")
        input("Press Enter to close the browser...")

        await browser.close()

asyncio.run(run())
