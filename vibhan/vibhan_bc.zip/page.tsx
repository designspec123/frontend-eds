"use client";

import { useState } from "react";
import axios from "axios";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import Link from "next/link";
import { ArrowBigLeft } from "lucide-react";

export default function WebsiteVerifier() {
  const [option1, setOption1] = useState<"URL" | "File">("File");
  const [option2, setOption2] = useState<"URL" | "File">("File");

  const [url1, setUrl1] = useState("");
  const [url2, setUrl2] = useState("");

  const [files1, setFiles1] = useState<File[]>([]);
  const [files2, setFiles2] = useState<File[]>([]);

  const [result, setResult] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleVerify = async () => {
    try {
      setIsProcessing(true);
      const formData = new FormData();

      if (option1 === "URL" && url1)
        formData.append("original_url", url1);
      if (option1 === "File" && files1.length > 0)
        formData.append("original_file", files1[0]);

      if (option2 === "URL" && url2)
        formData.append("design_url", url2);
      if (option2 === "File" && files2.length > 0)
        formData.append("design_file", files2[0]);

      const res = await axios.post(
        "http://127.0.0.1:8000/verify/file",
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );

      console.log("Server response data:", res.data);

      setResult(JSON.stringify(res.data.verification_result, null, 2));

    } catch (err) {
      console.error("Axios Error:", err);

      if (axios.isAxiosError(err) && err.response) {
        console.error("Server responded with a status code:", err.response.status);
        console.error("Response data:", err.response.data);
        console.error("Response headers:", err.response.headers);
        setResult(
          `Error: ${err.response.status} - ${JSON.stringify(err.response.data, null, 2)}`
        );
      } else if (axios.isAxiosError(err) && err.request) {
        console.error("No response received from the server:", err.request);
        setResult(`Error: No response from server. Check network connection.`);
      } else {
        console.error("Request setup error:", err.message);
        setResult(`Error: ${err.message}`);
      }
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-no-repeat bg-fixed bg-cover" style={{ background: "url('/images/eds-bg.jpg')" }}>
      <div className="pt-2">
        <Link href="/">
          <ArrowBigLeft className="text-white" />
        </Link>
      </div>
      <div className="container w-full p-5">
        <div className="text-white pt-5 p-2 flex flex-col justify-center items-center">
          <div className="text-center">
            <h1 className="text-white text-7xl text-center">DesignConform</h1>
            <h2 className="text-2xl font-bold text-white text-center mt-10 mb-10">Verify webpage design</h2>
          </div>
        </div>

        <div className="flex flex-col md:flex-row md:justify-center gap-10 mt-3">
          <div className="flex flex-col flex-1 gap-5 md:w-1/2">
            <Card className="mt-2 shadow-lg bg-pink-400/30 text-white">
              <CardHeader className="text-lg font-semibold">
                Original & Design Sources
              </CardHeader>
              <CardContent>
                {/* Original Source Section */}
                <div className="mb-6">
                  <Select
                    value={option1}
                    onValueChange={(v) => setOption1(v as "URL" | "File")}
                  >
                    <SelectTrigger className="w-[200px]">
                      <SelectValue placeholder="Original browse by URL or File" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="File">Original browse by File</SelectItem>
                      <SelectItem value="URL">Original browse by URL</SelectItem>
                    </SelectContent>
                  </Select>
                  {option1 === "URL" ? (
                    <Input
                      value={url1}
                      onChange={(e) => setUrl1(e.target.value)}
                      placeholder="https://example.com"
                      className="mt-4"
                    />
                  ) : (
                    <Input
                      type="file"
                      onChange={(e) => setFiles1(Array.from(e.target.files || []))}
                      className="mt-4"
                    />
                  )}
                </div>

                {/* Design Source Section */}
                <div className="mb-6">
                  <Select
                    value={option2}
                    onValueChange={(v) => setOption2(v as "URL" | "File")}
                  >
                    <SelectTrigger className="w-[200px]">
                      <SelectValue placeholder="Design browse by URL or File" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="File">Design browse by File</SelectItem>
                      <SelectItem value="URL">Design browse by URL</SelectItem>
                    </SelectContent>
                  </Select>
                  {option2 === "URL" ? (
                    <Input
                      value={url2}
                      onChange={(e) => setUrl2(e.target.value)}
                      placeholder="https://example.com"
                      className="mt-4"
                    />
                  ) : (
                    <Input
                      type="file"
                      onChange={(e) => setFiles2(Array.from(e.target.files || []))}
                      className="mt-4"
                    />
                  )}
                </div>

                <div className="flex justify-center mt-6">
                  <Button
                    onClick={handleVerify}
                    disabled={isProcessing}
                    className="px-8 py-4"
                  >
                    {isProcessing ? "Verifying..." : "Verify"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex-1 h-[600px] overflow-y-auto mt-5 md:w-1/2">
            {result && (
              <Card className="shadow-lg bg-gray-900 text-white h-full">
                <CardHeader className="text-lg font-semibold">
                  Verification Result
                </CardHeader>
                <CardContent>
                  <pre className="whitespace-pre-wrap text-sm">
                    {result}
                  </pre>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}