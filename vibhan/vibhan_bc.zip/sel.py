import os
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, ElementNotInteractableException
from webdriver_manager.chrome import ChromeDriverManager

def run_selenium_tests(html_file_path):
    """
    Runs a series of Selenium tests on the specified HTML file.
    This script is designed to be resilient to changes in class names
    by using IDs and tag names where possible.
    """
    # Initialize the webdriver service
    print("run_selenium_tests called")
    driver_path = ChromeDriverManager().install()
    service = Service(executable_path=driver_path)

    # Initialize the webdriver options
    options = Options()
    options.add_argument('headless')

    # Initialize the webdriver
    try:
        driver = webdriver.Chrome(service=service, options=options)
    except Exception as e:
        return {
            'status': 'error',
            'message': f'Failed to initialize webdriver: {str(e)}'
        }

    # Navigate to the HTML file URL
    try:
        driver.get('file://' + os.path.realpath(html_file_path))
    except Exception as e:
        return {
            'status': 'error',
            'message': f'Failed to navigate to the HTML file: {str(e)}'
        }

    # Test the contact form functionality
    try:
        # Find the "Name" input field by its ID
        name_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, 'name'))
        )

        # Scroll the element into view before trying to interact with it
        driver.execute_script("arguments[0].scrollIntoView(true);", name_input)

        # Wait for the element to become clickable after scrolling
        WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.ID, 'name'))
        )

        # Find other form elements
        email_input = driver.find_element(By.ID, 'email')
        comments_textarea = driver.find_element(By.ID, 'comments')

        # Add a small delay to ensure the page is fully ready
        time.sleep(1)

        # Fill out the form fields
        name_input.send_keys("Test Name")
        email_input.send_keys("test@example.com")
        comments_textarea.send_keys("This is a test comment.")

        # Find and click the "Send" button using its type
        send_button = driver.find_element(By.CSS_SELECTOR, 'button[type="submit"]')
        send_button.click()

        # Assuming the form submission doesn't change the page visibly, we just verify the click
        print("Form fields populated and button clicked successfully.")

    except (TimeoutException, NoSuchElementException, ElementNotInteractableException) as e:
        return {
            'status': 'error',
            'message': f'Failed to test form functionality: {str(e)}'
        }

    # Close the webdriver
    driver.quit()

    # Return the test result
    return {
        'status': 'success',
        'message': 'Form functionality tests passed on the transformed design.'
    }

if __name__ == "__main__":
    # Define the file paths
    # Note: Update these with the actual paths to your files
    original_file_path = "C:\\Users\\Vibhan\\Documents\\frontend-eds-main\\backend\\verify_files\\test.html"
    transformed_file_path = "C:\\Users\\Vibhan\\Documents\\frontend-eds-main\\backend\\verify_files\\transformed_test.htm"

    # Run the test on the original file
    print("Running tests on the original file...")
    original_results = run_selenium_tests(original_file_path)
    print(f"Original file test results: {original_results}")

    # Run the same test on the transformed file
    print("\nRunning tests on the transformed file...")
    transformed_results = run_selenium_tests(transformed_file_path)
    print(f"Transformed file test results: {transformed_results}")