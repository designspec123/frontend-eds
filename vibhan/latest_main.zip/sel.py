import os
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, ElementNotInteractableException
from webdriver_manager.chrome import ChromeDriverManager


def run_selenium_tests(html_file_path):
    """
    Runs a series of Selenium tests on the specified HTML file.
    Tests both the subscription form (email + subscribe button at top)
    and the contact form (name, email, comments, send button).
    """

    print("run_selenium_tests called")

    # Initialize the webdriver service
    driver_path = ChromeDriverManager().install()
    service = Service(executable_path=driver_path)

    # Initialize the webdriver options
    options = Options()
    options.add_argument('headless')

    # Initialize the webdriver
    try:
        driver = webdriver.Chrome(service=service, options=options)
    except Exception as e:
        return {
            'status': 'error',
            'message': f'Failed to initialize webdriver: {str(e)}',
            'tested_features': []
        }

    # Navigate to the HTML file URL
    try:
        driver.get('file://' + os.path.realpath(html_file_path))
    except Exception as e:
        return {
            'status': 'error',
            'message': f'Failed to navigate to the HTML file: {str(e)}',
            'tested_features': []
        }

    tested_features = []

    # -------------------------
    # Test subscription form
    # -------------------------
    try:
        subscription_email_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "form input[type='email']"))
        )
        tested_features.append('Subscription email input field found')

        # Scroll into view
        driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", subscription_email_input)
        WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "form input[type='email']"))
        )

        # Fill in subscription email
        subscription_email_input.send_keys("subscriber@example.com")

        # Locate Subscribe button
        subscribe_button = driver.find_element(By.XPATH, "//button[contains(text(), 'Subscribe')]")

        # Scroll into view & JS click to avoid intercepted clicks
        driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", subscribe_button)
        time.sleep(0.5)  # stability delay
        driver.execute_script("arguments[0].click();", subscribe_button)

        tested_features.append('Subscribe button successfully clicked (via JS)')
        print("Subscription email entered and Subscribe button clicked successfully.")
    except (TimeoutException, NoSuchElementException, ElementNotInteractableException) as e:
        return {
            'status': 'error',
            'message': f'Failed to test subscription functionality: {str(e)}',
            'tested_features': tested_features
        }

    # -------------------------
    # Test contact form
    # -------------------------
    try:
        # Wait for Name field
        name_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, 'name'))
        )
        tested_features.append('Name input field found')

        # Scroll into view
        driver.execute_script("arguments[0].scrollIntoView(true);", name_input)
        WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.ID, 'name'))
        )

        # Find other inputs
        email_input = driver.find_element(By.ID, 'email')
        comments_textarea = driver.find_element(By.ID, 'comments')
        tested_features.append('Email and Comments fields found')

        time.sleep(1)  # small delay

        # Fill contact form
        name_input.send_keys("Test Name")
        email_input.send_keys("test@example.com")
        comments_textarea.send_keys("This is a test comment.")
        tested_features.append('Contact form fields successfully populated')

        # Click Send button
        send_button = driver.find_element(By.CSS_SELECTOR, 'button[type="submit"]')
        driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", send_button)
        time.sleep(0.5)
        driver.execute_script("arguments[0].click();", send_button)

        tested_features.append('Send button successfully clicked (via JS)')
        print("Contact form fields populated and Send button clicked successfully.")
    except (TimeoutException, NoSuchElementException, ElementNotInteractableException) as e:
        return {
            'status': 'error',
            'message': f'Failed to test contact form functionality: {str(e)}',
            'tested_features': tested_features
        }

    # Close webdriver
    driver.quit()

    return {
        'status': 'success',
        'message': 'Subscription and Contact form functionality tests passed.',
        'tested_features': tested_features
    }



if __name__ == "__main__":
    # Define the file paths
    # Note: Update these with the actual paths to your files
    original_file_path = "C:\\Users\\Vibhan\\Documents\\frontend-eds-main\\backend\\verify_files\\test.html"
    transformed_file_path = "C:\\Users\\Vibhan\\Documents\\frontend-eds-main\\backend\\verify_files\\transformed_test.htm"

    # Run the test on the original file
    print("Running tests on the original file...")
    original_results = run_selenium_tests(original_file_path)
    print(f"Original file test results: {original_results}")

    # Run the same test on the transformed file
    print("\nRunning tests on the transformed file...")
    transformed_results = run_selenium_tests(transformed_file_path)
    print(f"Transformed file test results: {transformed_results}")